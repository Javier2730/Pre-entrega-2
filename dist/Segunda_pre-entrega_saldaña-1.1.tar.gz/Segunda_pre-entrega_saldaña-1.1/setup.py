import os
from setuptools import setup, find_packages

setup(
    name = "Segunda_pre-entrega_saldaña",
    version = "1.1",
    description = "Paquete distribuido para el proyecto de CoderHouse",
    author = "Javier Saldaña Cancino",
    author_email = "javieresteban.s27@gmail.com",
    packages = find_packages(["Segunda_pre-entrega_saldaña"]),
)